<img src="https://fountainofpeace.org.ug/wp-content/uploads/2023/08/resized-strch-fop-logo.png" class="w-64 h-auto" alt="Fountain of Peace Logo">
